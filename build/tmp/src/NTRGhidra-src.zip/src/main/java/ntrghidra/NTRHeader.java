package ntrghidra;

import java.io.IOException;

import ghidra.app.util.bin.BinaryReader;
import ghidra.app.util.bin.StructConverter;
import ghidra.program.model.data.DataType;
import ghidra.util.exception.DuplicateNameException;

public class NTRHeader implements StructConverter {

	private int crc;
	private final int crcFixed = 0x56CF;
	
	public NTRHeader(BinaryReader reader) throws IOException
	{

		crc = reader.readInt(0x15C);
		
		if (crc!=crcFixed)
		{
			throw new IOException("Not a Nintendo DS file.");
		}
		throw new IOException("CRC Value: " + crc);
	}
	
	@Override
	public DataType toDataType() throws DuplicateNameException, IOException {
		// TODO Auto-generated method stub
		return null;
	}

}
