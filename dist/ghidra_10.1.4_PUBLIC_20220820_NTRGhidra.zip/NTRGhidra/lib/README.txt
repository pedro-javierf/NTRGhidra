The "lib" directory is intended to hold Jar files which this module
is dependent upon.  This directory may be eliminated from a specific
module if no other Jar files are needed.
